import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fullwidth',
  templateUrl: './fullwidth.component.html',
  styleUrls: ['./fullwidth.component.css']
})
export class FullwidthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
