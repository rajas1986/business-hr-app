export interface IStates {
	Cattxt : string,
	Sno: string
}