import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DefaultModule } from './layouts/default/default.module';
/*import { FullwidthModule } from './layouts/fullwidth/fullwidth.module';*/
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { OdataService } from './odata.service';
import { HttpClientModule } from '@angular/common/http';
import { DialogdataComponent } from './modules/dialogdata/dialogdata.component';
import { MaterialModule } from './material.module';

@NgModule({
  declarations: [
    AppComponent,
    DialogdataComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    DefaultModule,
    /*FullwidthModule,*/
    BrowserAnimationsModule,
    HttpClientModule,
    MaterialModule
  ],
  providers: [OdataService],
  entryComponents: [DialogdataComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
