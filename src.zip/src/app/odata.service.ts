import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IStates } from './states';
import { Observable } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'Basic ' + btoa('P50002103:1q1q1q')
  })
};

@Injectable({
  providedIn: 'root'
})

export class OdataService {
  
  //private _url: string = "http://localhost/state_and_district/getStates.php";
  private _urlState: string = "http://localhost/state_and_district/getStates.php";
  private _urlCity: string = "http://localhost/state_and_district/getDistrict.php?state=";
  private _urlCities: string = "http://localhost/state_and_district/getDistrict.php?city=Ahmednagar";
  //private _urlRequisition: string = "http://localhost/state_and_district/getRequisition.php?orgunit=";
  private _urlRequisition: string = "/sap/opu/odata/sap/ZEREC_REQ_CREATE_SRV/GetPositionsSet";
  private _urlOrgUnit: string = "/sap/opu/odata/sap/ZEREC_REQ_CREATE_SRV/GetOrgSet";
  private orgUnitFilter1: string = "?$filter=ImMode eq 'INIT' and ImUname eq ''";
  private orgUnitFilter2: string = "?$filter=ImMode eq 'EXPAND' and ImUname eq ' ' and Objid eq ";
  private requisitionFilter: string = "?$filter=ImMode eq 'EXPAND' and ImUname eq ' ' and Objid eq ";
  private _stateMethod: string = "GetStateSet";

  //http://rrnwgwdev.ril.com:80/sap/opu/odata/sap/ZEREC_REQ_CREATE_SRV/GetPositionsSet?$filter=ImOrgeh eq '90001259' and ImStorecode eq 'DD' and ImUname eq 'P50002103' 

  constructor(private http: HttpClient) { }

  getStates(): Observable<any>{
  	//return this.http.get<IStates[]>(this._url+this._stateMethod);
  	return this.http.get<any>(this._urlState);
  }

  getCity(state): Observable<any>{
  	console.log(this._urlCity+state);
  	return this.http.get<any>(this._urlCity+state);
  }

  getStoreCode(): Observable<any>{
    //return this.http.get<IStates[]>(this._url+this._stateMethod);
    return this.http.get<any>(this._urlState);
  }

  getOrgUnit(storecode): Observable<any>{
    //return this.http.get<any>(this._urlCity+storecode);
    return this.http.get<any>(this._urlOrgUnit+this.orgUnitFilter1,httpOptions);
  }

  getOrgUnitByObjectId(objid): Observable<any>{
    //return this.http.get<any>(this._urlCity+storecode);
    return this.http.get<any>(this._urlOrgUnit+this.orgUnitFilter2+"'"+objid+"'",httpOptions);
  }

  getRequisition(result,storeCode): Observable<any>{
    console.log(result);
    console.log(storeCode);
    return this.http.get<any>(this._urlRequisition+"?$filter=ImOrgeh eq '"+result.objid+"' and ImStorecode eq '"+storeCode+"' and ImUname eq 'P50002103'");
  }

  getCities(): Observable<any>{
    console.log(this._urlCities);
    return this.http.get<any>(this._urlCities);
  }
  /*async getOrgUnit(storecode) {
    let data = await this.http.get<any>(this._urlCity+storecode).toPromise();
    console.log(data);
  }*/

}
