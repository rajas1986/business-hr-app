import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { OdataService } from '../../odata.service';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { DialogdataComponent } from '../dialogdata/dialogdata.component'
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {SelectionModel} from '@angular/cdk/collections';

export interface UserData {
  select: string;
  positioncode: string;
  fromdate: string;
  todate: string;
  positiondesc: string;
}

/** Constants used to fill up our data base. */
const COLORS: string[] = [
  'maroon', 'red', 'orange', 'yellow', 'olive', 'green', 'purple', 'fuchsia', 'lime', 'teal',
  'aqua', 'blue', 'navy', 'black', 'gray'
];
const NAMES: string[] = [
  'Maia', 'Asher', 'Olivia', 'Atticus', 'Amelia', 'Jack', 'Charlotte', 'Theodore', 'Isla', 'Oliver',
  'Isabella', 'Jasper', 'Cora', 'Levi', 'Violet', 'Arthur', 'Mia', 'Thomas', 'Elizabeth'
];

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public reqArr = [];
  public stateArray = [];
  public cityArray = [];
  //storecodeVal: string = '';
  public selectedStore = "";
  public orgunitArr = [];
  public selectedOrgUnit = "";
  //dataSource: Array<any> = [];
  public numRows = 0;
  show: boolean = true;
  public displayTable = 'none';

  displayedColumns: string[] = ['select', 'positioncode', 'fromdate', 'todate', 'positiondesc'];
  dataSource: MatTableDataSource<UserData>;
  selection = new SelectionModel<UserData>(true, []);

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild('storecodeVal', {static: true}) storecodeInputRef: ElementRef;

  filterForm: FormGroup;
  //prefilledForm: FormGroup;
  constructor(private _odataService: OdataService, private fb: FormBuilder, public dialog: MatDialog) { 

  }

  ngOnInit() {
    this.filterForm = this.fb.group({
      storecode: ['', Validators.required],
      orgunit: ['']
    });   
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  onStateChange(event){
    this._odataService.getCity(event.value).subscribe(data => this.cityArray = data);
  	console.log(event.value);
  }

  onStoreCodeChange(event){
    this.selectedStore = event.value;
  }

  openDialog(){
    //this.dialog.open(DialogdataComponent,{height: '300px', width: '500px', data: { storecode: this.selectedStore }});
    const dialogRef = this.dialog.open(DialogdataComponent,{width: '500px', data: { storecode: this.selectedStore }});


    dialogRef.afterClosed().subscribe(result => {
      console.log(this.storecodeInputRef.nativeElement.value);
      this._odataService.getRequisition(result,this.storecodeInputRef.nativeElement.value).subscribe((data)=>{
      const tableData = Array.from(data.d.results, (e, i) => createTableData(e,i));
        this.dataSource = new MatTableDataSource(tableData);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        console.log(tableData.length);
        if(tableData.length>0){
          this.displayTable='block';
          this.show=false;
        } else {
          this.displayTable='none';
          this.show=true;
        }
      });
    });
  }

  /** Whether the number of selected elements matches the total number of rows. */
  /*isAllSelected() {
    const numSelected = this.selection.selected.length;
    if(this.dataSource.hasOwnProperty("data")){
      this.numRows = this.dataSource.data.length;
    } 
    return numSelected === this.numRows;
  }

  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  checkboxLabel(row?: PeriodicElement): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  }*/

}

/** Builds and returns a table data. */
function createTableData(data, i): UserData {
  var fromDate = new Date(data.Begda.match(/\d+/)[0] * 1);
  let formatted_from_date = fromDate.getFullYear() + "-" + (fromDate.getMonth() + 1) + "-" + fromDate.getDate() + " " + fromDate.getHours() + ":" + fromDate.getMinutes() + ":" + fromDate.getSeconds(); 
  var toDate = new Date(data.Endda.match(/\d+/)[0] * 1);
  let formatted_to_date = toDate.getFullYear() + "-" + (toDate.getMonth() + 1) + "-" + toDate.getDate() + " " + toDate.getHours() + ":" + toDate.getMinutes() + ":" + toDate.getSeconds();
  return {
    select: i,
    positioncode: data.Objid,
    fromdate: formatted_from_date,
    todate: formatted_to_date,
    positiondesc: data.Stext
  };
}
